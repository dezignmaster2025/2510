import {useCallback, useEffect, useReducer, useState} from 'react';
import profilePicture1 from "../assets/profile_pic_1.jpg";
import profilePicture2 from "../assets/profile_pic_2.jpg";
import profilePicture3 from "../assets/profile_pic_3.jpg";
import sunset from "../assets/sunset.jpg"
import './home.css';
import {useLocalStorage} from '../hooks/local-storage.hooks';

const initialTweets = [
    {  
        id: 1,
        user: {
            name: 'John',
            username: 'john_88',
            photoId:profilePicture1
        },
        text: 'Giving standup comedy a go. Open mic starts at 7, hit me up if you want tickets',
        timestamp: "3m",
        commentCount: 1,
        likeCount: 8,
        photoId: null
    },
    {  
        id: 2,
        user: {
            name: 'Harold',
            username: 'h_wang',
            photoId:profilePicture2
        },
        text: 'Vacation is going great!',
        timestamp: "10m",
        commentCount: 3,
        likeCount: 14,
        photoId: sunset
    },
    {  
        id: 3,
        user: {
            name: 'Andrea',
            username: 'andy_landerson',
            photoId:profilePicture3
        },
        text: 'How many lemons do I need to make lemonade?',
        timestamp: "2m",
        commentCount: 10,
        likeCount: 5,
        photoId: null
    }
]

const initialState = {
    data: [],
    isLoading:false,
    error: null,
    searchKeyword: undefined,
}

const asyncExReducer = (state, action)=>{
    switch(action.type){
        case "FETCH_INIT":
            return {...state, isLoading: true}
        case "FETCH_SUCCESS":
            return {...state, isLoading: false, data: action.payload}
        case "FETCH_FAILURE" :
            return {...state, isLoading: false, error: action.payload}
        case "SET_SEARCH_KEYWORD":
            return {...state, searchKeyword: action.payload}
        default:
            return state
    }
}

const AsyncExample = ()=>{
    const [{data, isLoading, error, searchKeyword}, dispatch] = useReducer(asyncExReducer, initialState)
    
    const fetchData = useCallback((keyword="react")=>{
        dispatch({type: "FETCH_INIT"})
        fetch(`https://hn.algolia.com/api/v1/search?query=${keyword}`)
            .then((res)=>res.json())
            .then((body)=>{
                setTimeout(()=>{
                    dispatch({type: "FETCH_SUCCESS", payload: body.hits})
                },1500)
            })
            .catch((e)=>dispatch({type: "FETCH_FAILURE", payload: e.message}))
    },[])



    useEffect(()=>{
        fetchData();
    }, [])

    return (
        error 
        ? <p>An error has occurred</p> 
        : isLoading
        ? <>Loading...</>
        : (<div>
            <input type='text' onChange={(e)=>dispatch({type: "SET_SEARCH_KEYWORD", payload: e.target.value})}></input>
            <button onClick={()=>fetchData(searchKeyword)}>Refresh</button>
            {data.map((hit)=>
                <div key={hit.title}>
                    <p>{hit.title}</p>
                </div>
                )}
                {/* <Component dipatch={dispatch} state={state}/> */}
            </div>
            ))

    // {isLoading ? "Loading..." : "Hello!"}
    // {error ? error : "No errors"}
    
    
}

export const Home = ()=>{
    const [{data, isLoading, error, searchKeyword}, dispatch] = useReducer(asyncExReducer, initialState)
    const [tweets, setTweets] = useState(initialTweets)
    const [filteredTweets, setFilteredTweets] = useState([])
    const [value, setValue] = useLocalStorage("search-keyword", '')

    const handleSearch = (keyword)=>{
        const searchTweets = tweets.filter((tweet)=>tweet.text.includes(keyword))
        setValue(keyword)
        setFilteredTweets(searchTweets)
    }

    let modifiedTweets = tweets;
    if(filteredTweets.length > 0){
        modifiedTweets= filteredTweets;
    } 

    return <div className='home-container'>
        <AsyncExample />
      {/* <Navigation />
      <Feed tweets={modifiedTweets} setTweets={setTweets}/>
      <SideBar onChange={handleSearch} keyword={value} /> */}
    </div>
}

// filteredTweets.length > 0 ? filteredTweets : tweets 

// if(filteredTweets.length>0){
//     return filteredTweets;
// } else {
//     return tweets;
// }