# Lesson 6 — Starter & Bonus

This package contains two ready-to-run Vite + React projects for Lesson 6.

## Projects
- `lesson6-hw-starter/`: Minimal app showing JSX, components, list rendering with `map()` and `key`.
- `lesson6-hw-bonus/`: Adds a search box, separates data into `src/data/students.js`, and adds a `role` prop to `StudentCard`.

## How to run (both projects)
```bash
cd <project-folder>
npm install
npm run dev
```
Open the URL Vite prints (typically http://localhost:5173).

## Notes
- Uses React 18 and Vite with `@vitejs/plugin-react`.
- Ensure you have Node.js 20+ installed.
