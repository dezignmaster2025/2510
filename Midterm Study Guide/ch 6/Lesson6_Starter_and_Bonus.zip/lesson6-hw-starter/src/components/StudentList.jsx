import StudentCard from './StudentCard.jsx'

const STUDENTS = [
  { id: 'S001', name: 'Ada Lovelace', cohort: 'Spring' },
  { id: 'S002', name: 'Alan Turing', cohort: 'Fall' },
  { id: 'S003', name: 'Grace Hopper', cohort: 'Summer' },
]

export default function StudentList() {
  return (
    <section>
      <h2>Class Roster</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {STUDENTS.map((s) => (
          <li key={s.id}>
            <StudentCard id={s.id} name={s.name} cohort={s.cohort} />
          </li>
        ))}
      </ul>
    </section>
  )
}
