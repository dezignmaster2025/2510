export default function StudentCard({ id, name, cohort }) {
  return (
    <article className="card">
      <h3>{name}</h3>
      <p>ID: {id}</p>
      <p>Cohort: {cohort}</p>
    </article>
  )
}
