import StudentList from './components/StudentList.jsx'

export default function App() {
  return (
    <>
      <h1>Lesson 6 Homework — Bonus</h1>
      <StudentList />
    </>
  )
}
