import { useMemo, useState } from 'react'
import StudentCard from './StudentCard.jsx'
import { STUDENTS } from '../data/students.js'

export default function StudentList() {
  const [query, setQuery] = useState('')

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return STUDENTS
    return STUDENTS.filter(s => 
      s.name.toLowerCase().includes(q) ||
      s.id.toLowerCase().includes(q) ||
      s.cohort.toLowerCase().includes(q) ||
      (s.role && s.role.toLowerCase().includes(q))
    )
  }, [query])

  return (
    <section>
      <h2>Class Roster (Search enabled)</h2>
      <input
        placeholder="Search by name, id, cohort, or role..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{ padding: '0.5rem', marginBottom: '0.75rem', width: '100%', maxWidth: 420 }}
      />
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {filtered.map((s) => (
          <li key={s.id}>
            <StudentCard id={s.id} name={s.name} cohort={s.cohort} role={s.role} />
          </li>
        ))}
      </ul>
      {filtered.length === 0 && <p>No matches.</p>}
    </section>
  )
}
