export const STUDENTS = [
  { id: 'S001', name: 'Ada Lovelace', cohort: 'Spring', role: 'Analyst' },
  { id: 'S002', name: 'Alan Turing', cohort: 'Fall', role: 'Researcher' },
  { id: 'S003', name: 'Grace Hopper', cohort: 'Summer', role: 'Engineer' },
  { id: 'S004', name: 'Katherine Johnson', cohort: 'Winter', role: 'Mathematician' },
  { id: 'S005', name: 'Donald Knuth', cohort: 'Fall', role: 'Professor' }
]
