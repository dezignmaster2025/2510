Homework Assignment Answers:

1. What does `npm run dev` do?
   - It starts the Vite development server and opens your React app in the browser with hot module replacement.

2. What is the purpose of vite.config.js?
   - It configures Vite's behavior, including plugins like React and other build options.

3. What happens when you run `npm run build`?
   - Vite bundles and optimizes your React app for production, generating static files in the dist/ folder.
