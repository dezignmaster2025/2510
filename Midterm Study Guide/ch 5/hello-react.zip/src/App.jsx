function App() {
  return (
    <div>
      <h1>Hello React!</h1>
      <p>This is your first React component.</p>
    </div>
  );
}

export default App;
