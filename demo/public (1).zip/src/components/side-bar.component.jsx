
import './navigation.css'

export const SideBar = ()=>{
    return <section className="side-bar-container"></section>
}
