
import './navigation.css'

export const Feed = ()=>{
    return <section className="feed-container"></section>
}



