import './App.css'
import {Home} from './pages/home.page'

function App() {
  return (
    <>
      <div className="card" >
        <Home />
      </div>
    </>
  )
}

export default App

